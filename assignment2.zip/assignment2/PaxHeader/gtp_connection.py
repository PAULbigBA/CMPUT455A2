27 mtime=1695674247.739421
70 LIBARCHIVE.xattr.com.apple.quarantine=MDA4MTs2NTIwYWFjMztDaHJvbWU7
59 SCHILY.xattr.com.apple.quarantine=0081;6520aac3;Chrome;
57 LIBARCHIVE.xattr.com.apple.provenance=AQAA4SxS5nbMMao
49 SCHILY.xattr.com.apple.provenance=  �,R�v�1�
